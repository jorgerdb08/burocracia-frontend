# Expediente 02: Infraestructura Cloud AWS
Tipo Procedimiento: pago_proveedor
Proveedor: Amazon Web Services EMEA SARL
NIF: ESW0185696B
Importe: 145.50
Objeto: Servicios de computación e infraestructura en la nube AWS GPU
Fecha: 15/01/2026
Forma de Pago: Tarjeta
Num Tarjeta: 4812
