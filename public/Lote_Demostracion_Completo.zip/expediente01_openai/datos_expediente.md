# Expediente 01: Suscripción Inteligencia Artificial
Tipo Procedimiento: pago_proveedor
Proveedor: OpenAI, L.L.C.
NIF: EU372009942
Importe: 20.00
Objeto: Suscripción mensual al servicio de inteligencia artificial ChatGPT Plus / API
Fecha: 26/06/2026
Forma de Pago: Transferencia
