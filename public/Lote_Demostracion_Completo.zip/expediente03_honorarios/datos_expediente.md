# Expediente 03: Honorarios Conferencia Externa
Tipo Procedimiento: honorarios
Beneficiario: Dra. Elena Morales García
NIF: 09876543M
DNI: 09876543M
Domicilio: Calle Universidad s/n, Cáceres
Es Miembro UEx: No
Nombre Curso: Jornadas de Tecnologías Emergentes y Burocracia Digital 2026
Objeto: Honorarios por impartición de conferencia sobre Modelos de Lenguaje en la Administración
Importe: 300.00
Horas: 1
Es Conferencia: Sí
Fecha: 30/06/2026
IBAN: ES9121000418450200051332
