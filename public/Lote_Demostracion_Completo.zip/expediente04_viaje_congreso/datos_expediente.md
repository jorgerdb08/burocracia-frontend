# Expediente 04: Comisión de Servicios y Viaje a Madrid
Tipo Procedimiento: dietas
Comisionado: Prof. Dr. Pedro Clemente
DNI: 08855443X
Motivo: Asistencia y presentación de ponencia técnica en el Congreso Nacional de Software
Destino: Madrid
Fecha Salida: 2026-05-12T08:30:00
Fecha Regreso: 2026-05-14T20:45:00
Importe: 215.40
Transporte: Tren Renfe Alvia
Hotel: Hotel Eurostars Madrid Central
Forma de Pago: Transferencia
IBAN: ES9121000418450200051332
