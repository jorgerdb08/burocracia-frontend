# Contexto Común del Lote: Lote_Multiprocedimiento_GR24
- **Investigador Principal**: Prof. Dr. Pedro Clemente
- **Centro**: Escuela Politécnica
- **Campus**: Cáceres
- **Referencia Proyecto**: GR24099
- **Orgánica**: 18.IW.97.89
- **Tipo de Financiación**: G24
- **Forma de Pago**: Transferencia
- **Contacto**: pjclemente@unex.es
- **Fecha**: 2026-10-25
